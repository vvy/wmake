#include "1.h"

void func1(void)
{
    printf("func1 in 1.c.\n");
}
