#include "2.h"

int main()
{
    printf("in 2.c\n");
    func1();
}
